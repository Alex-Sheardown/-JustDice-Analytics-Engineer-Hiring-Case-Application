import pandas as pd
import mysql.connector as mysql

"""
This code is for uploading to mysql dataset
"""

# create a connection to the MySQL database
db = mysql.connect(
    host='',
    user='',
    password='',
    database=''
)


data = pd.read_csv('Data_Sets/Original/revenue.csv')
cursor = db.cursor()

# loop through the DataFrame and insert rows into the MySQL table
for i, row in data.iterrows():
    query = f"INSERT INTO revenue (install_id, event_date, value_usd) VALUES ('{row['install_id']}', '{row['event_date']}', '{row['value_usd']}')"
    cursor.execute(query)
    db.commit()

# close the database connection
db.close()